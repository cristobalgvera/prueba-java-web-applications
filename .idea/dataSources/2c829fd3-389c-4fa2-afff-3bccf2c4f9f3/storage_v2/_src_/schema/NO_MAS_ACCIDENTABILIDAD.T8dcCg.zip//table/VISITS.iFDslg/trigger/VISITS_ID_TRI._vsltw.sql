create trigger VISITS_ID_TRI
    before insert
    on VISITS
    for each row
BEGIN
SELECT visits_id_seq.NEXTVAL INTO :NEW.visit_id FROM DUAL;
END;
/

