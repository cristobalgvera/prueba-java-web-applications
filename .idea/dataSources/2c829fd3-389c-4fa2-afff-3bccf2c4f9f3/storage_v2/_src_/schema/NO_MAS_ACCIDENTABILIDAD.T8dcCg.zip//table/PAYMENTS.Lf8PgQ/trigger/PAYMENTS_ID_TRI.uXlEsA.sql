create trigger PAYMENTS_ID_TRI
    before insert
    on PAYMENTS
    for each row
BEGIN
SELECT payments_id_seq.NEXTVAL INTO :NEW.payment_id FROM DUAL;
END;
/

