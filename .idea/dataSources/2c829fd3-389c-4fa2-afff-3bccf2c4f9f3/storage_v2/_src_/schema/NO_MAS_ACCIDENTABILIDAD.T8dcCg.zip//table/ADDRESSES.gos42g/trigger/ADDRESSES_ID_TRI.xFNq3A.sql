create trigger ADDRESSES_ID_TRI
    before insert
    on ADDRESSES
    for each row
BEGIN
SELECT addresses_id_seq.NEXTVAL INTO :NEW.address_id FROM DUAL;
END;
/

