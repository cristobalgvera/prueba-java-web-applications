create trigger SUMMARIES_ID_TRI
    before insert
    on SUMMARIES
    for each row
BEGIN
SELECT summaries_id_seq.NEXTVAL INTO :NEW.summary_id FROM DUAL;
END;
/

