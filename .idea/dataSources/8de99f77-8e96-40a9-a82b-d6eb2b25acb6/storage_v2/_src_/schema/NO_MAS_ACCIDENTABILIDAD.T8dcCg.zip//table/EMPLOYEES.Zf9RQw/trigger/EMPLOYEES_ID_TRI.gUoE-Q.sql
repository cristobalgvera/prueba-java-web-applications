create trigger EMPLOYEES_ID_TRI
    before insert
    on EMPLOYEES
    for each row
BEGIN
SELECT employees_id_seq.NEXTVAL INTO :NEW.employee_id FROM DUAL;
END;
/

