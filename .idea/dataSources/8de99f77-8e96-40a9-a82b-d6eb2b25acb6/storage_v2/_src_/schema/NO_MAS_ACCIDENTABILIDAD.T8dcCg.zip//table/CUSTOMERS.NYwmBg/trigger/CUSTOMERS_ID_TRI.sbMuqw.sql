create trigger CUSTOMERS_ID_TRI
    before insert
    on CUSTOMERS
    for each row
BEGIN
SELECT customers_id_seq.NEXTVAL INTO :NEW.customer_id FROM DUAL;
END;
/

